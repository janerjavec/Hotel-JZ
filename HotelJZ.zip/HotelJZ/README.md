Naslov projekta: Hotel JZ
Imena avtorjev: Jan Erjavec 63220066 Žan Zrimšek 63220372
Opis: Spletna aplikacija za rezervacijo sob, storitve za goste, spletna storitev za komunikacijo z rezervacijskim sistemom, podatkovna baza za sledenje rezervacijam.